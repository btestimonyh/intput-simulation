import { useEffect, useState } from "react";
import { getTelegram } from "../util/telegram/getTelegram";
import { setTelegram } from "../util/telegram/setTelegram";


// import axios from "axios";
// import { API_URL } from "../util/URLs.js";


const Telegram = () => {
    const [input1, setInput1] = useState();


    useEffect(() => {
        const getData = async () => {
            const data = await getTelegram();
            setInput1(data);
        }

        getData();
    }, [])



    const handleButton1Click = () => {
        setTelegram(input1);
    };

    return <div className='relative max-md:w-[100%] flex flex-col gap-4 w-full items-center'>
        <div className="text-white text-[14px] max-sm:text-[12px] text-center self-start">Telegram username ( without adress and @ ) Example - &quot;username&quot;</div>
        <div className="flex bg-white rounded-xl p-2 items-center gap-4 w-full">
            <input
                type="text"
                className='w-full h-auto'
                placeholder="Enter telegram"
                value={input1}
                onChange={e => setInput1(e.target.value)}
            />
        </div>


        <button onClick={handleButton1Click}
            className='bg-[rgb(15,117,252)] hover:bg-[#123276] text-[rgb(255,255,255)]  rounded-[8px] p-3 px-40 max-md:px-20 w-full'>
            Set Telegram</button>
    </div>
}

export default Telegram;