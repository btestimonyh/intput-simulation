import { useEffect, useState } from "react";
import {getLink} from "../util/link/getLink.js";
import {putLink} from "../util/link/putLink.js";
// import axios from "axios";
// import { API_URL } from "../util/URLs.js";


const Message = () => {
    const [input1, setInput1] = useState();


    useEffect(() => {
        const getData = async () => {
            const data = await getLink();
            setInput1(data);
        }

        getData();
    }, [])



    const handleButton1Click = () => {
        putLink(input1);
    };

    return <div className='relative max-md:w-[100%] flex flex-col gap-4 w-full items-center'>
        <div className="flex bg-white rounded-xl p-2 items-center gap-4 w-full">
            <textarea
                className='w-full h-auto'
                style={{ resize: 'none' }}
                placeholder="Enter message"
                value={input1}
                onChange={e => setInput1(e.target.value)}
            />
        </div>


        <button onClick={handleButton1Click}
            className='bg-[rgb(15,117,252)] hover:bg-[#123276] text-[rgb(255,255,255)]  rounded-[8px] p-3 px-40 max-md:px-20 w-full'>
            Set Link In Error Message Content</button>
    </div>
}

export default Message;