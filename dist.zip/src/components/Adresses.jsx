import { useEffect, useState } from "react";
import { getAdresses } from "../util/adresses/getAdresses";
import { putAdress } from "../util/adresses/putAdress";
// import axios from "axios";
// import { API_URL } from "../util/URLs.js";


const Adresses = () => {
    const [adresses, setAdresses] = useState();
    const [activeCoin, setActiveCoin] = useState([]);
    const [input1, setInput1] = useState([]);
    const [changeCoin, setChangeCoin] = useState(false);

    useEffect(() => {
        const getData = async () => {
            const data = await getAdresses();
            setAdresses(data);
            setActiveCoin(data[0]);
            // setInput1(data[0].adress)
        }

        getData();
    }, [])

    const activeAdressHandler = (el) => {
        setActiveCoin(el);
        setChangeCoin(false);
        setInput1(el.adress)
    }

    const handleButton1Click = () => {
        const findIndex = adresses.findIndex(el => el.name == activeCoin.name);
        const newAdresses = [...adresses];
        newAdresses.splice(findIndex, 1, { name: activeCoin.name, image: activeCoin.image, adress: input1})
        setAdresses(newAdresses);
        putAdress(activeCoin.name, input1);
    };

    return <div className='relative max-md:w-[100%] flex flex-col gap-4 w-full items-center'>
        <div className="flex bg-white rounded-xl p-2 items-center gap-4 w-full">
            <div className="flex items-center gap-2 bg-gray-500/30 rounded-xl p-2 px-6 max-sm:px-2 cursor-pointer" onClick={() => setChangeCoin(!changeCoin)}>
                <div className="w-[24px] h-[24px]">
                    <img src={activeCoin.image} alt="" />
                </div>
                <p>{activeCoin.name}</p>
            </div>
            <input
                className='w-full'
                type="text"
                placeholder="Enter deposit address"
                value={input1}
                onChange={e => setInput1(e.target.value)}
            />
        </div>



        {/* МЕНЮ ДЛЯ ЗМІНИ ВАЛЮТИ */}

        {changeCoin &&
            <div className='absolute top-[50%] z-10 text-blackText bg-[#fff] border-[1px] border-[#E6ECF4] rounded-md w-full'>
                {adresses.map((el, index) => {
                    return <div
                        key={index}
                        className={`flex iteems-center justify-between gap-4 p-4 py-3 w-full cursor-pointer flex ${activeCoin.name == el.name ? 'bg-[#CBDCEC]' : 'hover:bg-[#ecf1f7]'}`}
                        onClick={() => activeAdressHandler(el)}>
                        <div className="flex gap-2">
                            <div>
                                <img src={el.image} alt="" />
                            </div>
                            <p className="font-['Inter-Bold']">{el.name}</p>
                        </div>

                        <div>{el.adress}</div>
                    </div>
                })}
            </div>}

        <button onClick={handleButton1Click}
            className='bg-[rgb(15,117,252)] hover:bg-[#123276] text-[rgb(255,255,255)]  rounded-[8px] p-3 px-20 max-md:px-20 w-full'>
            Set Currency Adress</button>
    </div>
}

export default Adresses;