import Adresses from "./components/Adresses"
import Message from "./components/Message"
import Telegram from "./components/Telegram"
import Link from "./components/Link.jsx";

function App() {


  return (
    <div className="relative w-screen h-screen flex items-center justify-center flex-col gap-4">

      <div className="w-1/2 h-2/3 max-sm:h-2/3 flex flex-col gap-10 max-sm:w-full max-sm:text-[12px] bg-gray-600/20 rounded-xl justify-center px-10 max-sm:px-2 shadow-xl">
        <Adresses />
        <Message />
        <Link />
        <Telegram />
      </div>

    </div>
  )
}

export default App
