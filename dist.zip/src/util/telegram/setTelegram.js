import {API_URL} from "../util.js";

export const setTelegram = async (url) => {
    console.log(url);
    async function setAddresses() {
        try {
            const response = await fetch(API_URL + "/crypt/settg/" + url);
            console.log(response)
            return await response.text();
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }
    const setData = await setAddresses();
    console.log(setData)
}