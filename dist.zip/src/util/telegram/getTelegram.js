import {API_URL} from "../util.js";

export const getTelegram = async () => {
    async function fetchAddresses() {
        try {
            const response = await fetch(API_URL + "/crypt/gettg");
            console.log(response)
            return await response.text();
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }
    const returnedData = await fetchAddresses();
    console.log(returnedData)
    return returnedData;
}