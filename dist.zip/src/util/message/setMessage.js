import {API_URL} from "../util.js";

export const setMessage = async (message) => {
    const dto = {
        errMsgText: message
    }
    try {
        const response = await fetch(API_URL + "/crypt/seterr", {
            method: 'POST',
            headers: {
                'Content-Type': 'text/plain',
            },
            body: message,
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
    } catch (error) {
        console.error('Error:', error);
        throw error; // Propagate the error so the calling code can handle it
    }
}