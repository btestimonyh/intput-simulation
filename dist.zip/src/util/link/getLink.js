import {API_URL} from "../util.js";

export const getLink = async () =>{
    async function fetchAddresses() {
        try {
            const response = await fetch(API_URL + "/crypt/getlink");
            console.log(response)
            return await response.text();
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }
    const returnedData = await fetchAddresses();
    console.log(returnedData)
    return returnedData;
}