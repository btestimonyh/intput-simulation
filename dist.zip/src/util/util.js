export const API_URL = "https://simpleswap.tech:6001"
// export const API_URL = "http://localhost:8080"