import {API_URL} from "../util.js";

export const getAdresses = async () => {

    async function fetchAddresses() {
        try {
            const response = await fetch(API_URL + "/crypt");
            console.log(response)
            return await response.json();
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }
    const fetchedData = await fetchAddresses();
    const dataToReturn = [
        { name: "BTC", image: './images/coins/btc.svg', adress: fetchedData.BTC },
        { name: "ETH", image: './images/coins/eth.svg', adress: fetchedData.ETH },
        { name: "USDT", image: './images/coins/usdt.svg', adress: fetchedData.USDT },
        { name: "TRX", image: './images/coins/trx.svg', adress: fetchedData.TRX },
        { name: "MXN", image: './images/coins/mxn.svg', adress: fetchedData.MXN },
        { name: "COP", image: './images/coins/cop.svg', adress: fetchedData.COP },
        { name: "PEN", image: './images/coins/pen.svg', adress: fetchedData.PEN },
    ];
    console.log(dataToReturn)
    return dataToReturn;
}