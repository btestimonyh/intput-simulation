import {API_URL} from "../util.js";

export const putAdress = async (name, adress) =>{
    console.log(adress);
    console.log(name);
    async function putNewAddressValue() {
        try {
            const response = await fetch(API_URL + `/crypt/set/${name}/${adress}`);
            console.log(response)
            return await response.json();
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }
    await putNewAddressValue()
}